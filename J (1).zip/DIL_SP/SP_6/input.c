
int main() {
int x = 5;
    int y=10;
    int sum=0;
    sum=x+y;
}