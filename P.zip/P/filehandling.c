#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void createFile();
void writeFile();
void readFile();
void appendFile();

int main() {
    int choice;

    while (1) {
        printf("\nFile Handling Menu\n");
        printf("1. Create a file\n");
        printf("2. Write to a file\n");
        printf("3. Read from a file\n");
        printf("4. Append to a file\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar();  // To consume the newline character left by scanf

        switch (choice) {
            case 1:
                createFile();
                break;
            case 2:
                writeFile();
                break;
            case 3:
                readFile();
                break;
            case 4:
                appendFile();
                break;
            case 5:
                printf("Exiting...\n");
                exit(0);
            default:
                printf("Invalid choice! Please try again.\n");
        }
    }
    return 0;
}

void createFile() {
    FILE *fptr;
    char filename[100];

    printf("Enter the filename to create: ");
    scanf("%s", filename);
    getchar();  // To consume the newline character left by scanf

    fptr = fopen(filename, "w");
    if (fptr == NULL) {
        printf("Error creating file!\n");
        return;
    }

    printf("File created successfully.\n");
    fclose(fptr);
}

void writeFile() {
    FILE *fptr;
    char filename[100];
    char input[255];

    // Get the filename from the user
    printf("Enter the filename to write to: ");
    scanf("%s", filename);
    getchar();  // To consume the newline character left by scanf

    // Open the file in write mode
    fptr = fopen(filename, "w");
    if (fptr == NULL) {
        printf("Error opening file!\n");
        return;
    }

    // Get the text input from the user
    printf("Enter text to write to the file (end with a single dot on a new line):\n");
    while (1) {
        fgets(input, sizeof(input), stdin);
        if (strcmp(input, ".\n") == 0) {
            break;
        }
        fputs(input, fptr);
    }

    printf("Text written to the file successfully.\n");
    fclose(fptr);
}

void readFile() {
    FILE *fptr;
    char filename[100];

    printf("Enter the filename to read from: ");
    scanf("%s", filename);
    getchar();  // To consume the newline character left by scanf

    fptr = fopen(filename, "r");
    if (fptr == NULL) {
        printf("Error opening file!\n");
        return;
    }

    printf("Contents of the file:\n");
    char ch;
    while ((ch = fgetc(fptr)) != EOF) {
        putchar(ch);
    }

    fclose(fptr);
}

void appendFile() {
    FILE *fptr;
    char filename[100];
    char input[255];

    printf("Enter the filename to append to: ");
    scanf("%s", filename);
    getchar();  // To consume the newline character left by scanf

    fptr = fopen(filename, "a");
    if (fptr == NULL) {
        printf("Error opening file!\n");
        return;
    }

    printf("Enter text to append to the file (end with a single dot on a new line):\n");
    while (1) {
        fgets(input, sizeof(input), stdin);
        if (strcmp(input, ".\n") == 0) {
            break;
        }
        fputs(input, fptr);
    }

    printf("Text appended to the file successfully.\n");
    fclose(fptr);
}
