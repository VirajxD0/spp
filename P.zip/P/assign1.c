#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#define MAX_LINE_LENGTH 100
#define MAX_TOKEN_LENGTH 20

typedef struct {
 const char *mnemonic;
 int length;
 const char *opcode;
} Mnemonic;

typedef struct {
 char symbol[MAX_TOKEN_LENGTH];
 int address;
} Symbol;

Mnemonic mnemonics[] = {
 {"STOP", 1, "01"}, {"ADD", 3, "02"}, {"SUB", 3, "03"},
 {"MULT", 3, "04"}, {"MOVER", 3, "05"}, {"MOVEM", 3, "06"},
 {"DIV", 3, "07"}, {"READ", 2, "08"}, {"PRINT", 2, "09"},
 {"DS", 0, "00"}, {"DC", 0, "00"}, {"START", 0, "00"}, {"END", 0, "00"}
};

const int num_mnemonics = sizeof(mnemonics) / sizeof(mnemonics[0]);
const char *registers[] = {"AX", "BX", "CX", "DX", "SI", "DI", "BP", "SP"};
const int num_registers = sizeof(registers) / sizeof(registers[0]);
Symbol symbol_table[100];
int symbol_count = 0;

void save_to_file(FILE *file, const char *token, int address) {
 fprintf(file, "%-10s %04d\n", token, address);
}
void save_mnemonic_to_file(FILE *file, const char *token, int address) {
 for (int i = 0; i < num_mnemonics; i++) {
 if (strcmp(token, mnemonics[i].mnemonic) == 0) {
 fprintf(file, "%-10s %s %04d\n", token, mnemonics[i].opcode, address);
 return;
 }
 }
}

const char *get_mnemonic_opcode(const char *token) {
 for (int i = 0; i < num_mnemonics; i++) {
 if (strcmp(token, mnemonics[i].mnemonic) == 0) {
 return mnemonics[i].opcode;
 }
 }
 return "";
}

int get_mnemonic_length(const char *token) {
 for (int i = 0; i < num_mnemonics; i++) {
 if (strcmp(token, mnemonics[i].mnemonic) == 0) {
 return mnemonics[i].length;
 }
 }
 return 0;
}

int is_mnemonic(const char *token) {
 for (int i = 0; i < num_mnemonics; i++) {
 if (strcmp(token, mnemonics[i].mnemonic) == 0) {
 return 1;
 }
 }
 return 0;
}

int is_register(const char *token) {
 for (int i = 0; i < num_registers; i++) {
 if (strcmp(token, registers[i]) == 0) {
 return 1;
 }
 }
 return 0;
}

int is_symbol(const char *token) {
 return !is_mnemonic(token) && !is_register(token) && strlen(token) > 0;
}

int is_lc(const char *token) {
 for (int i = 0; token[i] != '\0'; i++) {
 if (!isdigit((unsigned char)token[i])) {
 return 0;
 }
 }
 return 1;
}

void process_ds(const char *token, FILE *symbols_file, int *lc) {
 int size = atoi(token);
 if (size > 0) {
 *lc += size;
 }
}

void process_dc(const char *token, FILE *symbols_file, int *lc) {
 // Assuming DC values are comma-separated integers
 char *values = strdup(token);
 char *value = strtok(values, ",");
 while (value != NULL) {
 fprintf(symbols_file, "%04d %s\n", *lc, value);
 (*lc)++;
 value = strtok(NULL, ",");
 }
 free(values);
}

void log_error(FILE *error_file, const char *line, const char *error_message) {
 fprintf(error_file, "Error: %s -> %s\n", error_message, line);
}

void process_line(char *line, FILE *mnemonics_file, FILE *registers_file, FILE *symbols_file, FILE *lc_file, FILE *error_file, int *lc) {
    char *token = strtok(line, " ,");
    int line_lc = *lc;
    int line_length = 0;
    const char *opcode = "";
    int valid_mnemonic_found = 0;

    while (token != NULL) {
        while (isspace((unsigned char)*token)) token++;
        char *end = token + strlen(token) - 1;
        while (end > token && isspace((unsigned char)*end)) end--;
        *(end + 1) = '\0';

        if (is_lc(token)) {
            line_lc = atoi(token);
        } else if (strcmp(token, "DS") == 0) {
            token = strtok(NULL, " ,");
            if (!is_lc(token)) {
                log_error(error_file, line, "Invalid size format for DS");
                return;
            }
            process_ds(token, symbols_file, lc);
        } else if (strcmp(token, "DC") == 0) {
            token = strtok(NULL, " ,");
            if (token == NULL || !is_lc(token)) {
                log_error(error_file, line, "Invalid constant format for DC");
                return;
            }
            process_dc(token, symbols_file, lc);
        } else if (is_mnemonic(token)) {
            save_mnemonic_to_file(mnemonics_file, token, line_lc);
            opcode = get_mnemonic_opcode(token);
            line_length += get_mnemonic_length(token);
            valid_mnemonic_found = 1;
        } else if (is_register(token)) {
            save_to_file(registers_file, token, line_lc);
        } else if (is_symbol(token)) {
            strcpy(symbol_table[symbol_count].symbol, token);
            symbol_table[symbol_count].address = line_lc;
            symbol_count++;
            save_to_file(symbols_file, token, line_lc);
        } else {
            log_error(error_file, line, "Invalid token");
            return;
        }
        token = strtok(NULL, " ,");
    }

    if (!valid_mnemonic_found && strlen(opcode) == 0) {
        log_error(error_file, line, "Invalid mnemonic");
        return;
    }

    fprintf(lc_file, "LC: %04d %s -> %s\n", line_lc, opcode, line);
    *lc = line_lc + line_length;
}

void add_assembly_code() {
 FILE *mnemonics_file = fopen("mnemonics.txt", "a");
 FILE *registers_file = fopen("registers.txt", "a");
 FILE *symbols_file = fopen("symbols.txt", "a");
 FILE *lc_file = fopen("lc_table.txt", "a");
 FILE *error_file = fopen("errors.txt", "a");
 if (!mnemonics_file || !registers_file || !symbols_file || !lc_file || !error_file) {
 perror("Error opening one of the files");
 if (mnemonics_file) fclose(mnemonics_file);
 if (registers_file) fclose(registers_file);
 if (symbols_file) fclose(symbols_file);
 if (lc_file) fclose(lc_file);
 if (error_file) fclose(error_file);
 return;
 }
 char line[MAX_LINE_LENGTH];
 int lc = 0;
 printf("Enter assembly code line by line (enter an empty line to finish):\n");
 while (1) {
 printf("> ");
 if (fgets(line, sizeof(line), stdin) == NULL || line[0] == '\n') {
 break;
 }
 process_line(line, mnemonics_file, registers_file, symbols_file, lc_file, error_file, &lc);
 }
 fclose(mnemonics_file);
 fclose(registers_file);
 fclose(symbols_file);
 fclose(lc_file);
 fclose(error_file);
 printf("Processing complete. Mnemonics, registers, symbols, and LC table saved to respective files.\n");
}

void view_table(const char *filename) {
 FILE *file = fopen(filename, "r");
 if (file == NULL) {
 perror("Error opening file");
 return;
 }
 char line[MAX_LINE_LENGTH];
 while (fgets(line, sizeof(line), file) != NULL) {
 printf("%s", line);
 }
 fclose(file);
}

void view_lc_table() {
 view_table("lc_table.txt");
}

void view_error_report() {
 view_table("errors.txt");
}

int main() {
 int choice;
 do {
 printf("\nMenu:\n");
 printf("1. Add Assembly Code\n");
 printf("2. View Mnemonics Table\n");
 printf("3. View Registers Table\n");
 printf("4. View Symbols Table\n");
 printf("5. View LC Table\n");
 printf("6. View Error Report\n");
 printf("7. Exit\n");
 printf("Enter your choice: ");
 scanf("%d", &choice);
 getchar(); // To consume the newline character left by scanf
 switch (choice) {
 case 1:
 add_assembly_code();
 break;
 case 2:
 view_table("mnemonics.txt");
 break;
 case 3:
 view_table("registers.txt");
 break;
 case 4:
 view_table("symbols.txt");
 break;
 case 5:
 view_lc_table();
 break;
 case 6:
 view_error_report();
 break;
 case 7:
 printf("Exiting the program.\n");
 break;
 default:
 printf("Invalid choice. Please try again.\n");
 break;
 }
 } while (choice != 7);
 return 0;
}