#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_NAME 50
#define MAX_LINE 100
#define MAX_TABLE_SIZE 100

// Define structures for tables
typedef struct {
    char* name;
    int pp;
    int kp;
    int mdtp;
    int kpdtp;
    int sstp;
    int evtp;
} MNT;

typedef struct {
    int index;
    char* card;
} MDT;

typedef struct {
    char* name;
    char type;
    int number;
} PNTAB;

typedef struct {
    char* name;
    int number;
} EVNTAB;

typedef struct {
    char* name;
    int mdtp;
} SSNTAB;

typedef struct {
    char* param;
    char* value;
} KPDTAB;

typedef struct {
    char* param;
    int value;
} APTAB;

typedef struct {
    char* name;
    int value;
} SVTAB;

typedef struct {
    char* name;
    int value;
} SSTAB;

// Function to allocate and initialize a new table entry
void* new_entry(size_t size) {
    return malloc(size);
}

// Function to free a table entry
void free_entry(void* ptr) {
    free(ptr);
}

// Function to read a line from a file, handling errors
int read_line(FILE* fp, char* buffer, int max_length) {
    if (fgets(buffer, max_length, fp) == NULL) {
        if (feof(fp)) {
            return 0;
        } else {
            fprintf(stderr, "Error reading from file.\n");
            return -1;
        }
    }
    buffer[strcspn(buffer, "\n")] = 0;  // Remove newline
    return 1;
}

// Function to process macro definition
void process_macro_definition(FILE* fp, MNT** mnt, int* mnt_count, MDT** mdt, int* mdt_count, PNTAB** pntab, int* pntab_count, KPDTAB** kpdtab, int* kpdtab_count, SSNTAB** ssntab, int* ssntab_count, EVNTAB** evntab, int* evntab_count, APTAB** aptab, int* aptab_count, SVTAB** svtab, int* svtab_count, SSTAB** sstab, int* sstab_count) {
    char line[MAX_LINE];
    int inside_macro = 0;

    while (read_line(fp, line, MAX_LINE) > 0) {
        if (strstr(line, "MACRO") != NULL) {
            inside_macro = 1;
            // Parse macro definition and update tables
            char macro_name[MAX_NAME];
            sscanf(line, "%s", macro_name); // Get macro name directly
            MNT* entry = (MNT*)new_entry(sizeof(MNT));
            entry->name = (char*)new_entry(MAX_NAME * sizeof(char));
            strcpy(entry->name, macro_name);
            entry->mdtp = *mdt_count; // Set MDT pointer
            entry->pp = 0;
            entry->kp = 0;
            entry->kpdtp = -1; // Initialize to -1 if not used
            entry->sstp = -1; // Initialize to -1 if not used
            entry->evtp = -1; // Initialize to -1 if not used

            // Process parameters
            char* token = strtok(line, " \t,");
            while ((token = strtok(NULL, " \t,")) != NULL) {
                if (strchr(token, '=') != NULL) {
                    // Keyword parameter
                    char param[MAX_NAME], value[MAX_NAME];
                    sscanf(token, "%[^=]=%s", param, value);
                    PNTAB* pntab_entry = (PNTAB*)new_entry(sizeof(PNTAB));
                    pntab_entry->name = (char*)new_entry(MAX_NAME * sizeof(char));
                    strcpy(pntab_entry->name, param);
                    pntab_entry->type = 'K';
                    pntab_entry->number = entry->kp;
                    pntab[*pntab_count] = pntab_entry;
                    (*pntab_count)++;

                    KPDTAB* kpdtab_entry = (KPDTAB*)new_entry(sizeof(KPDTAB));
                    kpdtab_entry->param = (char*)new_entry(MAX_NAME * sizeof(char));
                    kpdtab_entry->value = (char*)new_entry(MAX_NAME * sizeof(char));
                    strcpy(kpdtab_entry->param, param);
                    strcpy(kpdtab_entry->value, value);
                    kpdtab[*kpdtab_count] = kpdtab_entry;
                    (*kpdtab_count)++;
                } else {
                    // Positional parameter
                    PNTAB* pntab_entry = (PNTAB*)new_entry(sizeof(PNTAB));
                    pntab_entry->name = (char*)new_entry(MAX_NAME * sizeof(char));
                    strcpy(pntab_entry->name, token);
                    pntab_entry->type = 'P';
                    pntab_entry->number = entry->pp;
                    pntab[*pntab_count] = pntab_entry;
                    (*pntab_count)++;

                    entry->pp++;
                }
            }
            mnt[*mnt_count] = entry;
            (*mnt_count)++;
        } else if (strstr(line, "MEND") != NULL) {
            inside_macro = 0;
            MDT* mdt_entry = (MDT*)new_entry(sizeof(MDT));
            mdt_entry->card = (char*)new_entry(MAX_LINE * sizeof(char));
            strcpy(mdt_entry->card, line);
            mdt_entry->index = *mdt_count;
            mdt[*mdt_count] = mdt_entry;
            (*mdt_count)++;
        } else if (inside_macro) {
            MDT* mdt_entry = (MDT*)new_entry(sizeof(MDT));
            mdt_entry->card = (char*)new_entry(MAX_LINE * sizeof(char));
            strcpy(mdt_entry->card, line);
            mdt_entry->index = *mdt_count;
            mdt[*mdt_count] = mdt_entry;
            (*mdt_count)++;

            // Check for sequence symbols
            if (strstr(line, ".") == line) {
                char symbol[MAX_NAME];
                sscanf(line, ".%s", symbol);
                SSNTAB* ssntab_entry = (SSNTAB*)new_entry(sizeof(SSNTAB));
                ssntab_entry->name = (char*)new_entry(MAX_NAME * sizeof(char));
                strcpy(ssntab_entry->name, symbol);
                ssntab_entry->mdtp = *mdt_count - 1;
                ssntab[*ssntab_count] = ssntab_entry;
                (*ssntab_count)++;
            }
        } else {
            // Process macro calls
            char macro_name[MAX_NAME];
            sscanf(line, "%s", macro_name);
            MNT* macro_def = NULL;
            for (int i = 0; i < *mnt_count; i++) {
                if (strcmp(mnt[i]->name, macro_name) == 0) {
                    macro_def = mnt[i];
                    break;
                }
            }
            if (macro_def != NULL) {
                // Process actual parameters
                char* token = strtok(line, " \t,");
                token = strtok(NULL, " \t,");
                int param_count = 0;
                while (token != NULL) {
                    APTAB* aptab_entry = (APTAB*)new_entry(sizeof(APTAB));
                    aptab_entry->param = (char*)new_entry(MAX_NAME * sizeof(char));
                    strcpy(aptab_entry->param, token);
                    aptab_entry->value = param_count;  // Store actual parameter values
                    aptab[*aptab_count] = aptab_entry;
                    (*aptab_count)++;
                    token = strtok(NULL, " \t,");
                    param_count++;
                }
            }
        }
    }
}

// Display functions for each table
void display_mnt(MNT** mnt, int mnt_count) {
    printf("\nMacro Name Table (MNT):\n");
    printf("Name\tPP\tKP\tMDTP\tKPDTP\tSSTP\tEVTP\n");
    for (int i = 0; i < mnt_count; i++) {
        printf("%s\t%d\t%d\t%d\t%d\t%d\t%d\n",
               mnt[i]->name, mnt[i]->pp, mnt[i]->kp, mnt[i]->mdtp,
               mnt[i]->kpdtp, mnt[i]->sstp, mnt[i]->evtp);
    }
}

void display_mdt(MDT** mdt, int mdt_count, PNTAB** pntab, int pntab_count) {
    printf("\nMacro Definition Table (MDT):\n");
    printf("Index\tInstruction\n");
    for (int i = 0; i < mdt_count; i++) {
        if (strstr(mdt[i]->card, "LDA") != NULL ||
            strstr(mdt[i]->card, "ADD") != NULL ||
            strstr(mdt[i]->card, "STA") != NULL ||
            strstr(mdt[i]->card, "SUB") != NULL ||
            strstr(mdt[i]->card, "BR") != NULL) {
            // Replace parameters with (Type,Number)
            for (int j = 0; j < pntab_count; j++) {
                char param[MAX_NAME];
                sprintf(param, "&%s", pntab[j]->name);
                if (strstr(mdt[i]->card, param) != NULL) {
                    char type_num[MAX_NAME];
                    sprintf(type_num, "(%c,%d)", pntab[j]->type, pntab[j]->number);
                    char* pos = strstr(mdt[i]->card, param);
                    memmove(pos + strlen(type_num), pos + strlen(param), strlen(pos + strlen(param)) + 1);
                    memcpy(pos, type_num, strlen(type_num));
                }
            }
        }
        printf("%d\t%s\n", mdt[i]->index, mdt[i]->card);
    }
}

void display_pntab(PNTAB** pntab, int pntab_count) {
    printf("\nParameter Name Table (PNTAB):\n");
    printf("Parameter\tType\tNumber\n");  // Show parameter types
    for (int i = 0; i < pntab_count; i++) {
        printf("%s\t%c\t%d\n", pntab[i]->name, pntab[i]->type, pntab[i]->number);
    }
}

void display_evntab(EVNTAB** evntab, int evntab_count) {
    printf("\nExpansion Variable Name Table (EVNTAB):\n");
    printf("Name\tNumber\n");
    for (int i = 0; i < evntab_count; i++) {
        printf("%s\t%d\n", evntab[i]->name, evntab[i]->number);
    }
}

void display_ssntab(SSNTAB** ssntab, int ssntab_count) {
    printf("\nSequence Symbol Name Table (SSNTAB):\n");
    printf("Name\tMDTP\n");
    for (int i = 0; i < ssntab_count; i++) {
        printf("%s\t%d\n", ssntab[i]->name, ssntab[i]->mdtp);
    }
}

void display_kpdtab(KPDTAB** kpdtab, int kpdtab_count) {
    printf("\nKeyword Parameter Default Table (KPDTAB):\n");
    printf("Parameter\tDefault Value\n");
    for (int i = 0; i < kpdtab_count; i++) {
        printf("%s\t%s\n", kpdtab[i]->param, kpdtab[i]->value);
    }
}

void display_aptab(APTAB** aptab, int aptab_count) {
    printf("\nActual Parameter Table (APTAB):\n");
    printf("Parameter\tValue\n");
    for (int i = 0; i < aptab_count; i++) {
        printf("%s\t%d\n", aptab[i]->param, aptab[i]->value);
    }
}

void display_svtab(SVTAB** svtab, int svtab_count) {
    printf("\nSystem Variable Table (SVTAB):\n");
    printf("Name\tValue\n");
    for (int i = 0; i < svtab_count; i++) {
        printf("%s\t%d\n", svtab[i]->name, svtab[i]->value);
    }
}

void display_sstab(SSTAB** sstab, int sstab_count) {
    printf("\nSequence Symbol Table (SSTAB):\n");
    printf("Name\tValue\n");
    for (int i = 0; i < sstab_count; i++) {
        printf("%s\t%d\n", sstab[i]->name, sstab[i]->value);
    }
}

// Function to save tables to files
void save_tables_to_files(MNT** mnt, int mnt_count, MDT** mdt, int mdt_count, PNTAB** pntab, int pntab_count, KPDTAB** kpdtab, int kpdtab_count, SSNTAB** ssntab, int ssntab_count) {
    FILE* mnt_file = fopen("mnt.txt", "w");
    FILE* mdt_file = fopen("mdt.txt", "w");
    FILE* pntab_file = fopen("pntab.txt", "w");
    FILE* kpdtab_file = fopen("kpdtab.txt", "w");
    FILE* ssntab_file = fopen("ssntab.txt", "w");

    if (mnt_file != NULL) {
        for (int i = 0; i < mnt_count; i++) {
            fprintf(mnt_file, "%s\t%d\t%d\t%d\t%d\t%d\t%d\n",
                    mnt[i]->name, mnt[i]->pp, mnt[i]->kp, mnt[i]->mdtp,
                    mnt[i]->kpdtp, mnt[i]->sstp, mnt[i]->evtp);
        }
        fclose(mnt_file);
    }

    if (mdt_file != NULL) {
        for (int i = 0; i < mdt_count; i++) {
            fprintf(mdt_file, "%d\t%s\n", mdt[i]->index, mdt[i]->card);
        }
        fclose(mdt_file);
    }

    if (pntab_file != NULL) {
        for (int i = 0; i < pntab_count; i++) {
            fprintf(pntab_file, "%s\t%c\t%d\n", pntab[i]->name, pntab[i]->type, pntab[i]->number);
        }
        fclose(pntab_file);
    }

    if (kpdtab_file != NULL) {
        for (int i = 0; i < kpdtab_count; i++) {
            fprintf(kpdtab_file, "%s\t%s\n", kpdtab[i]->param, kpdtab[i]->value);
        }
        fclose(kpdtab_file);
    }

    if (ssntab_file != NULL) {
        for (int i = 0; i < ssntab_count; i++) {
            fprintf(ssntab_file, "%s\t%d\n", ssntab[i]->name, ssntab[i]->mdtp);
        }
        fclose(ssntab_file);
    }
}

// Main function
int main() {
    MNT** mnt = (MNT**)malloc(MAX_TABLE_SIZE * sizeof(MNT*));
    MDT** mdt = (MDT**)malloc(MAX_TABLE_SIZE * sizeof(MDT*));
    PNTAB** pntab = (PNTAB**)malloc(MAX_TABLE_SIZE * sizeof(PNTAB*));
    EVNTAB** evntab = (EVNTAB**)malloc(MAX_TABLE_SIZE * sizeof(EVNTAB*));
    SSNTAB** ssntab = (SSNTAB**)malloc(MAX_TABLE_SIZE * sizeof(SSNTAB*));
    KPDTAB** kpdtab = (KPDTAB**)malloc(MAX_TABLE_SIZE * sizeof(KPDTAB*));
    APTAB** aptab = (APTAB**)malloc(MAX_TABLE_SIZE * sizeof(APTAB*));
    SVTAB** svtab = (SVTAB**)malloc(MAX_TABLE_SIZE * sizeof(SVTAB*));
    SSTAB** sstab = (SSTAB**)malloc(MAX_TABLE_SIZE * sizeof(SSTAB*));

    int mnt_count = 0;
    int mdt_count = 0;
    int pntab_count = 0;
    int evntab_count = 0;
    int ssntab_count = 0;
    int kpdtab_count = 0;
    int aptab_count = 0;
    int svtab_count = 0;
    int sstab_count = 0;

    int svg_count = 0;

    // Initialize system variable table
    svtab[svg_count] = (SVTAB*)malloc(sizeof(SVTAB));
    svtab[svg_count]->name = (char*)malloc(MAX_NAME * sizeof(char));
    strcpy(svtab[svg_count]->name, "SYSNDX");
    svtab[svg_count]->value = 1;
    svg_count++;

    char filename[MAX_NAME];
    FILE* fp;

    printf("Enter source file name: ");
    scanf("%s", filename);
    fp = fopen(filename, "r");
    if (fp != NULL) {
        process_macro_definition(fp, mnt, &mnt_count, mdt, &mdt_count, pntab, &pntab_count, kpdtab, &kpdtab_count, ssntab, &ssntab_count, evntab, &evntab_count, aptab, &aptab_count, svtab, &svtab_count, sstab, &sstab_count);
        fclose(fp);
        printf("Macro definition processed successfully.\n");
    } else {
        fprintf(stderr, "Error opening file.\n");
        return 1;
    }

    int choice;
    while (1) {
        printf("\nMenu:\n");
        printf("1. Display Macro Name Table (MNT)\n");
        printf("2. Display Macro Definition Table (MDT)\n");
        printf("3. Display Parameter Name Table (PNTAB)\n");
        printf("4. Display Expansion Variable Name Table (EVNTAB)\n");
        printf("5. Display Sequence Symbol Name Table (SSNTAB)\n");
        printf("6. Display Keyword Parameter Default Table (KPDTAB)\n");
        printf("7. Display Actual Parameter Table (APTAB)\n");
        printf("8. Display System Variable Table (SVTAB)\n");
        printf("9. Display Sequence Symbol Table (SSTAB)\n");
        printf("10. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                display_mnt(mnt, mnt_count);
                break;
            case 2:
                display_mdt(mdt, mdt_count, pntab, pntab_count);
                break;
            case 3:
                display_pntab(pntab, pntab_count);
                break;
            case 4:
                display_evntab(evntab, evntab_count);
                break;
            case 5:
                display_ssntab(ssntab, ssntab_count);
                break;
            case 6:
                display_kpdtab(kpdtab, kpdtab_count);
                break;
            case 7:
                display_aptab(aptab, aptab_count);
                break;
            case 8:
                display_svtab(svtab, svtab_count);
                break;
            case 9:
                display_sstab(sstab, sstab_count);
                break;
            case 10:
                save_tables_to_files(mnt, mnt_count, mdt, mdt_count, pntab, pntab_count, kpdtab, kpdtab_count, ssntab, ssntab_count);
                printf("Tables saved to files successfully.\n");
                return 0;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }

    // Free allocated memory
    for (int i = 0; i < mnt_count; i++) {
        free(mnt[i]->name);
        free(mnt[i]);
    }
    free(mnt);

    for (int i = 0; i < mdt_count; i++) {
        free(mdt[i]->card);
        free(mdt[i]);
    }
    free(mdt);

    for (int i = 0; i < pntab_count; i++) {
        free(pntab[i]->name);
        free(pntab[i]);
    }
    free(pntab);

    for (int i = 0; i < evntab_count; i++) {
        free(evntab[i]->name);
        free(evntab[i]);
    }
    free(evntab);

    for (int i = 0; i < ssntab_count; i++) {
        free(ssntab[i]->name);
        free(ssntab[i]);
    }
    free(ssntab);

    for (int i = 0; i < kpdtab_count; i++) {
        free(kpdtab[i]->param);
        free(kpdtab[i]->value);
        free(kpdtab[i]);
    }
    free(kpdtab);

    for (int i = 0; i < aptab_count; i++) {
        free(aptab[i]->param);
        free(aptab[i]);
    }
    free(aptab);

    for (int i = 0; i < svtab_count; i++) {
        free(svtab[i]->name);
        free(svtab[i]);
    }
    free(svtab);

    for (int i = 0; i < sstab_count; i++) {
        free(sstab[i]->name);
        free(sstab[i]);
    }
    free(sstab);

    return 0;
}