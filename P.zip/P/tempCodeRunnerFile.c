#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LINE 1000
#define MAX_SYMBOLS 1000
#define MAX_INTERMEDIATE_CODE 1000
#define MAX_MACHINE_CODE 1000
#define MAX_FILENAME 256

// Struct definitions
typedef struct {
    char name[20];
    int address;
} Symbol;

typedef struct {
    int lc;
    char code[MAX_LINE];
} CodeLine;

typedef struct {
    int lc;
    int opcode;
    int operand;
} MachineInstruction;

// Global variables
Symbol symbolTable[MAX_SYMBOLS];
int symbolCount = 0;
CodeLine intermediateCode[MAX_INTERMEDIATE_CODE];
int intermediateCodeCount = 0;
MachineInstruction machineCode[MAX_MACHINE_CODE];
int machineCodeCount = 0;
char symbolFilename[MAX_FILENAME] = "symbols.txt";
char intermediateFilename[MAX_FILENAME] = "ic.txt";
char machineFilename[MAX_FILENAME] = "machine_code.txt";

// Function prototypes
void readSymbolFile();
void readIntermediateFile();
void generateMachineCode();
void writeMachineCodeToFile();
int getSymbolAddress(char *name);
int getOpcode(char *mnemonic);
void viewFileContent(const char *filename);
void displayMenu();
char* trim(char* str);

// Main function
int main() {
    int choice;
    do {
        displayMenu();
        scanf("%d", &choice);
        getchar(); // Consume newline

        switch(choice) {
            case 1:
                readSymbolFile();
                break;
            case 2:
                readIntermediateFile();
                break;
            case 3:
                generateMachineCode();
                break;
            case 4:
                viewFileContent(symbolFilename);
                break;
            case 5:
                viewFileContent(intermediateFilename);
                break;
            case 6:
                viewFileContent(machineFilename);
                break;
            case 0:
                printf("Exiting program.\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 0);

    return 0;
}

void readSymbolFile() {
    FILE* file = fopen(symbolFilename, "r");
    if (file == NULL) {
        printf("Error opening symbol file for reading.\n");
        return;
    }

    symbolCount = 0;
    char line[MAX_LINE];
    while (fgets(line, sizeof(line), file)) {
        char name[20];
        int address;
        if (sscanf(line, "%s %d", name, &address) == 2) {
            strcpy(symbolTable[symbolCount].name, name);
            symbolTable[symbolCount].address = address;
            symbolCount++;
        }
    }

    fclose(file);
    printf("Symbol file read successfully from %s.\n", symbolFilename);
}

void readIntermediateFile() {
    FILE* file = fopen(intermediateFilename, "r");
    if (file == NULL) {
        printf("Error opening intermediate code file for reading.\n");
        return;
    }

    intermediateCodeCount = 0;
    char line[MAX_LINE];
    while (fgets(line, sizeof(line), file)) {
        int lc;
        char code[MAX_LINE];
        if (sscanf(line, "%d %[^\n]", &lc, code) == 2) {
            intermediateCode[intermediateCodeCount].lc = lc;
            strcpy(intermediateCode[intermediateCodeCount].code, code);
            intermediateCodeCount++;
        }
    }

    fclose(file);
    printf("Intermediate code file read successfully from %s.\n", intermediateFilename);
}

void generateMachineCode() {
    if (intermediateCodeCount == 0) {
        printf("Intermediate code is empty. Please read the intermediate code file first.\n");
        return;
    }

    machineCodeCount = 0;
    for (int i = 0; i < intermediateCodeCount; i++) {
        int lc = intermediateCode[i].lc;
        char mnemonic[20], operand[20];
        int opcode = 0, address = 0;

        if (sscanf(intermediateCode[i].code, "%s %s", mnemonic, operand) == 2) {
            opcode = getOpcode(mnemonic);
            address = getSymbolAddress(operand);
        } else if (sscanf(intermediateCode[i].code, "%s", mnemonic) == 1) {
            opcode = getOpcode(mnemonic);
            address = -1;
        }

        machineCode[machineCodeCount].lc = lc;
        machineCode[machineCodeCount].opcode = opcode;
        machineCode[machineCodeCount].operand = address;
        machineCodeCount++;
    }

    writeMachineCodeToFile();
    printf("Machine code generated and saved to %s successfully.\n", machineFilename);
}

int getSymbolAddress(char *name) {
    for (int i = 0; i < symbolCount; i++) {
        if (strcmp(symbolTable[i].name, name) == 0) {
            return symbolTable[i].address;
        }
    }
    return -1; // Indicate error
}

int getOpcode(char *mnemonic) {
    // Example of opcode mapping
    if (strcmp(mnemonic, "START") == 0) return 0;
    if (strcmp(mnemonic, "READ") == 0) return 1;
    if (strcmp(mnemonic, "MOVER") == 0) return 2;
    if (strcmp(mnemonic, "ADD") == 0) return 3;
    if (strcmp(mnemonic, "MOVEM") == 0) return 4;
    if (strcmp(mnemonic, "PRINT") == 0) return 5;
    if (strcmp(mnemonic, "STOP") == 0) return 6;

    return -1; // Indicate error
}

void writeMachineCodeToFile() {
    FILE* file = fopen(machineFilename, "w");
    if (file == NULL) {
        printf("Error opening machine code file for writing.\n");
        return;
    }

    for (int i = 0; i < machineCodeCount; i++) {
        fprintf(file, "%d %d %d\n", machineCode[i].lc, machineCode[i].opcode, machineCode[i].operand);
    }

    fclose(file);
}

void viewFileContent(const char *filename) {
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file %s for reading.\n", filename);
        return;
    }

    char line[MAX_LINE];
    printf("\nContent of %s:\n", filename);
    while (fgets(line, sizeof(line), file)) {
        printf("%s", line);
    }

    fclose(file);
}

void displayMenu() {
    printf("\nAssembler Code Processor Menu\n");
    printf("1. Read Symbol File\n");
    printf("2. Read Intermediate Code File\n");
    printf("3. Generate Machine Code File\n");
    printf("4. View Symbol File\n");
    printf("5. View Intermediate Code File\n");
    printf("6. View Machine Code File\n");
    printf("0. Exit\n");
    printf("Enter your choice: ");
}

char* trim(char* str) {
    char* end;
    while(isspace((unsigned char)*str)) str++;
    if(*str == 0) return str;
    end = str + strlen(str) - 1;
    while(end > str && isspace((unsigned char)*end)) end--;
    end[1] = '\0';
    return str;
}
