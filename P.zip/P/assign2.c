#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX_LINE_LENGTH 100
#define MAX_TOKEN_LENGTH 20
#define MAX_LITERALS 100
#define MAX_SYMBOLS 100
#define MAX_POOLS 100
#define MAX_REGISTERS 10

typedef struct {
    char mnemonic[MAX_TOKEN_LENGTH];
    int length;
    char opcode[MAX_TOKEN_LENGTH];
} Mnemonic;

typedef struct {
    char symbol[MAX_TOKEN_LENGTH];
    int address;
} Symbol;

typedef struct {
    char literal[MAX_TOKEN_LENGTH];
    int address;
    int index;
} Literal;

typedef struct {
    int start_index;
    int end_index;
} Pool;

typedef struct {
    char register_name[MAX_TOKEN_LENGTH];
    char register_code[MAX_TOKEN_LENGTH];
} Register;

const Mnemonic mnemonics[] = {
    {"STOP", 1, "01"}, {"ADD", 3, "02"}, {"SUB", 3, "03"},
    {"MULT", 3, "04"}, {"MOVER", 3, "05"}, {"MOVEM", 3, "06"},
    {"DIV", 3, "07"}, {"READ", 2, "08"}, {"PRINT", 2, "09"},
    {"DS", 0, "00"}, {"DC", 0, "00"}, {"START", 0, "00"}, {"END", 0, "00"},
    {"LTORG", 0, "00"}, {"ORIGIN", 0, "00"}, {"BC", 0, "00"}, {"EQU", 0, "00"}
};

const Register registers[MAX_REGISTERS] = {
    {"AX", "01"}, {"BX", "02"}, {"CX", "03"}, {"DX", "04"},
    {"SI", "05"}, {"DI", "06"}, {"BP", "07"}, {"SP", "08"},
};

const int num_mnemonics = sizeof(mnemonics) / sizeof(mnemonics[0]);
const int num_registers = sizeof(registers) / sizeof(registers[0]);

Symbol symbol_table[MAX_SYMBOLS];
Literal literal_table[MAX_LITERALS];
Pool pool_table[MAX_POOLS];

int symbol_count = 0;
int literal_count = 0;
int pool_count = 0;
int lc = 0;
int used_registers[MAX_REGISTERS] = {0};

char *trim_whitespace(char *str) {
    char *end;
    while (isspace((unsigned char)*str)) str++;
    if (*str == 0) return str;
    end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end)) end--;
    *(end + 1) = '\0';
    return str;
}

const Mnemonic* find_mnemonic(const char *token) {
    for (int i = 0; i < num_mnemonics; i++) {
        if (strcmp(token, mnemonics[i].mnemonic) == 0) {
            return &mnemonics[i];
        }
    }
    return NULL;
}

const Register* find_register(const char *token) {
    for (int i = 0; i < num_registers; i++) {
        if (strcmp(token, registers[i].register_name) == 0) {
            return &registers[i];
        }
    }
    return NULL;
}

void log_error(FILE *error_file, const char *line, const char *error_message) {
    fprintf(error_file, "Error: %s -> %s\n", error_message, line);
}

void record_used_register(const char *reg) {
    const Register* reg_info = find_register(reg);
    if (reg_info) {
        for (int i = 0; i < num_registers; i++) {
            if (strcmp(reg, registers[i].register_name) == 0) {
                used_registers[i] = 1;
                return;
            }
        }
    }
}

void assign_literal_addresses() {
    for (int i = 0; i < pool_count; i++) {
        int start = (i == 0) ? 0 : pool_table[i-1].start_index;
        for (int j = start; j < pool_table[i].start_index; j++) {
            literal_table[j].address = lc++;
        }
    }
    // Handle literals after the last LTORG
    for (int j = pool_table[pool_count-1].start_index; j < literal_count; j++) {
        literal_table[j].address = lc++;
    }
}

void process_line(char *line, FILE *intermediate_file, FILE *error_file) {
    char *token = strtok(line, " \t,");
    int valid_mnemonic_found = 0;
    char label[MAX_TOKEN_LENGTH] = "";
    char mnemonic[MAX_TOKEN_LENGTH] = "";
    char operand1[MAX_TOKEN_LENGTH] = "";
    char operand2[MAX_TOKEN_LENGTH] = "";

    // Check for label
    if (isalpha(token[0]) && !find_mnemonic(token)) {
        strcpy(label, token);
        // Add symbol to symbol table
        if (symbol_count < MAX_SYMBOLS) {
            strcpy(symbol_table[symbol_count].symbol, label);
            symbol_table[symbol_count].address = lc;
            symbol_count++;
        } else {
            log_error(error_file, line, "Symbol table full");
        }
        token = strtok(NULL, " \t,");
    }

    // Process mnemonic
    if (token) {
        const Mnemonic* mnemonic_info = find_mnemonic(token);
        if (mnemonic_info) {
            strcpy(mnemonic, token);
            valid_mnemonic_found = 1;
        } else {
            log_error(error_file, line, "Invalid mnemonic");
            return;
        }
    }

    // Process operands
    for (int i = 0; i < 2 && token; i++) {
        token = strtok(NULL, " \t,");
        if (token) {
            if (i == 0) strcpy(operand1, token);
            else strcpy(operand2, token);
        }
    }

    // Handle special cases
    if (strcmp(mnemonic, "START") == 0) {
        if (operand1[0] && isdigit(operand1[0])) {
            lc = atoi(operand1);
        } else {
            log_error(error_file, line, "Invalid address for START");
            return;
        }
    } else if (strcmp(mnemonic, "LTORG") == 0) {
        if (pool_count < MAX_POOLS) {
            if (pool_count > 0 && pool_table[pool_count-1].end_index == -1) {
                pool_table[pool_count-1].end_index = literal_count;
            }
            pool_table[pool_count].start_index = literal_count;
            pool_table[pool_count].end_index = -1;
            pool_count++;
            // Assign addresses to literals in the current pool
            for (int i = pool_table[pool_count-1].start_index; i < literal_count; i++) {
                literal_table[i].address = lc++;
            }
        } else {
            log_error(error_file, line, "Pool table full");
        }
    } else if (strcmp(mnemonic, "LTORG") == 0) {
        if (pool_count < MAX_POOLS) {
            if (pool_count > 0 && pool_table[pool_count-1].end_index == -1) {
                pool_table[pool_count-1].end_index = literal_count;
            }
            pool_table[pool_count].start_index = literal_count;
            pool_table[pool_count].end_index = -1;
            pool_count++;
            // Assign addresses to literals in the current pool
            for (int i = pool_table[pool_count-1].start_index; i < literal_count; i++) {
                literal_table[i].address = lc++;
            }
        } else {
            log_error(error_file, line, "Pool table full");
        }
    } else if (strcmp(mnemonic, "END") == 0) {
        // Close the last pool if it's open
        if (pool_count > 0 && pool_table[pool_count-1].end_index == -1) {
            pool_table[pool_count-1].end_index = literal_count;
        }
        // Add final pool if there are any unprocessed literals
        if (literal_count > 0 && (pool_count == 0 || pool_table[pool_count-1].end_index < literal_count)) {
            if (pool_count < MAX_POOLS) {
                pool_table[pool_count].start_index = (pool_count > 0) ? pool_table[pool_count-1].end_index : 0;
                pool_table[pool_count].end_index = literal_count;
                pool_count++;
            } else {
                log_error(error_file, line, "Pool table full");
            }
        }
        // Assign addresses to any remaining literals
        for (int i = (pool_count > 0 ? pool_table[pool_count-1].start_index : 0); i < literal_count; i++) {
            literal_table[i].address = lc++;
        }
    }

    // Generate intermediate code
    fprintf(intermediate_file, "%04d\t", lc);
    if (label[0]) fprintf(intermediate_file, "%s\t", label);
    else fprintf(intermediate_file, "\t");
    fprintf(intermediate_file, "%s\t", mnemonic);

    const Mnemonic* mnemonic_info = find_mnemonic(mnemonic);
    if (mnemonic_info) {
        fprintf(intermediate_file, "%s\t", mnemonic_info->opcode);

        if (operand1[0]) {
            const Register* reg_info = find_register(operand1);
            if (reg_info) {
                fprintf(intermediate_file, "%s\t", reg_info->register_code);
                record_used_register(operand1);
            } else if (operand1[0] == '=') {
                // Handle literal
                if (literal_count < MAX_LITERALS) {
                    Literal* lit = &literal_table[literal_count++];
                    strcpy(lit->literal, operand1);
                    lit->address = -1;
                    lit->index = literal_count;
                    fprintf(intermediate_file, "L%d\t", lit->index);
                }
            } else {
                fprintf(intermediate_file, "%s\t", operand1);
            }
        } else {
            fprintf(intermediate_file, "\t");
        }

        if (operand2[0]) {
            const Register* reg_info = find_register(operand2);
            if (reg_info) {
                fprintf(intermediate_file, "%s", reg_info->register_code);
                record_used_register(operand2);
            } else if (operand2[0] == '=') {
                // Handle literal
                if (literal_count < MAX_LITERALS) {
                    Literal* lit = &literal_table[literal_count++];
                    strcpy(lit->literal, operand2);
                    lit->address = -1;
                    lit->index = literal_count;
                    fprintf(intermediate_file, "L%d", lit->index);
                }
            } else {
                fprintf(intermediate_file, "%s", operand2);
            }
        }
    }

    fprintf(intermediate_file, "\n");

    // Update location counter
    if (mnemonic_info) {
        lc += mnemonic_info->length;
    }

    if (!valid_mnemonic_found) {
        log_error(error_file, line, "No valid mnemonic found in the line");
    }
}

void finalize_tables() {
    FILE *literal_file = fopen("literals.txt", "w");
    FILE *pool_file = fopen("pools.txt", "w");
    FILE *symbol_file = fopen("symbols.txt", "w");
    FILE *register_file = fopen("registers.txt", "w");

    if (!literal_file || !pool_file || !symbol_file || !register_file) {
        perror("Error opening file");
        if (literal_file) fclose(literal_file);
        if (pool_file) fclose(pool_file);
        if (symbol_file) fclose(symbol_file);
        if (register_file) fclose(register_file);
        return;
    }

    // Write symbol table
    fprintf(symbol_file, "Symbol Address\n");
    for (int i = 0; i < symbol_count; i++) {
        fprintf(symbol_file, "%s %d\n", symbol_table[i].symbol, symbol_table[i].address);
    }
    fclose(symbol_file);

    // Write literal table
    fprintf(literal_file, "Index Literal Address\n");
    for (int i = 0; i < literal_count; i++) {
        fprintf(literal_file, "%d %s %d\n", literal_table[i].index, literal_table[i].literal, literal_table[i].address);
    }
    fclose(literal_file);

    // Write pool table
     fprintf(pool_file, "Pool_Index Literal_Index\n");
    for (int i = 0; i < pool_count; i++) {
        for (int j = pool_table[i].start_index; j < pool_table[i].end_index; j++) {
            fprintf(pool_file, "%d %d\n", i + 1, literal_table[j].index);
        }
    }
    fclose(pool_file);

    // Write register table
    fprintf(register_file, "Register_Name Register_Code\n");
    for (int i = 0; i < num_registers; i++) {
        if (used_registers[i]) {
            fprintf(register_file, "%s %s\n", registers[i].register_name, registers[i].register_code);
        }
    }
    fclose(register_file);
}

void process_assembly_code() {
    FILE *intermediate_file = fopen("intermediate.txt", "w");
    FILE *error_file = fopen("errors.txt", "w");

    if (!intermediate_file || !error_file) {
        perror("Error opening one of the files");
        if (intermediate_file) fclose(intermediate_file);
        if (error_file) fclose(error_file);
        return;
    }

    char line[MAX_LINE_LENGTH];
    printf("Enter assembly code line by line (enter an empty line to finish):\n");
    while (1) {
        printf("> ");
        if (fgets(line, sizeof(line), stdin) == NULL || line[0] == '\n') {
            break;
        }
        process_line(line, intermediate_file, error_file);
    }
    if (pool_count > 0 && pool_table[pool_count-1].end_index == -1) {
        pool_table[pool_count-1].end_index = literal_count;
    }
    if (literal_count > 0 && (pool_count == 0 || pool_table[pool_count-1].end_index < literal_count)) {
        if (pool_count < MAX_POOLS) {
            pool_table[pool_count].start_index = (pool_count > 0) ? pool_table[pool_count-1].end_index : 0;
            pool_table[pool_count].end_index = literal_count;
            pool_count++;
        }
    }


    // Assign addresses to any remaining literals
    for (int i = (pool_count > 0 ? pool_table[pool_count-1].start_index : 0); i < literal_count; i++) {
        literal_table[i].address = lc++;
    }
    assign_literal_addresses();

    fclose(intermediate_file);
    fclose(error_file);

    finalize_tables();

    printf("Processing complete. Intermediate code, literals, symbols, pools, and registers saved.\n");
}

void view_file(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        return;
    }
    char line[MAX_LINE_LENGTH];
    while (fgets(line, sizeof(line), file) != NULL) {
        printf("%s", line);
    }
    fclose(file);
}

int main() {
    int choice;
    do {
        printf("\nMenu:\n");
        printf("1. Process Assembly Code\n");
        printf("2. View Intermediate Code\n");
        printf("3. View Symbol Table\n");
        printf("4. View Literal Table\n");
        printf("5. View Pool Table\n");
        printf("6. View Register Table\n");
        printf("7. View Error Report\n");
        printf("8. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar();  // To consume the newline character left by scanf

        switch (choice) {
            case 1:
                process_assembly_code();
                break;
            case 2:
                view_file("intermediate.txt");
                break;
            case 3:
                view_file("symbols.txt");
                break;
            case 4:
                view_file("literals.txt");
                break;
            case 5:
                view_file("pools.txt");
                break;
            case 6:
                view_file("registers.txt");
                break;
            case 7:
                view_file("errors.txt");
                break;
            case 8:
                printf("Exiting the program.\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
                break;
        }
    } while (choice != 8);

    return 0;
}