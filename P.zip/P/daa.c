#include <stdio.h>

typedef struct {
    float profit;
    float weight;
    float ratio;
} Object;

// Function to merge two sorted arrays
void merge(Object arr[], int left, int mid, int right) {
    int i, j, k;
    int n1 = mid - left + 1;
    int n2 = right - mid;

    Object leftArr[n1], rightArr[n2];

    for (i = 0; i < n1; i++)
        leftArr[i] = arr[left + i];
    for (j = 0; j < n2; j++)
        rightArr[j] = arr[mid + 1 + j];

    i = 0;
    j = 0;
    k = left;

    while (i < n1 && j < n2) {
        if (leftArr[i].ratio >= rightArr[j].ratio) {
            arr[k] = leftArr[i];
            i++;
        } else {
            arr[k] = rightArr[j];
            j++;
        }
        k++;
    }

    while (i < n1) {
        arr[k] = leftArr[i];
        i++;
        k++;
    }

    while (j < n2) {
        arr[k] = rightArr[j];
        j++;
        k++;
    }
}

void mergeSort(Object arr[], int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;

        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);

        merge(arr, left, mid, right);
    }
}

int main() {
    int n;
    printf("Enter the number of objects: ");
    scanf("%d", &n);

    Object objects[n];
    printf("Enter the profits and weights of the objects:\n");
    for (int i = 0; i < n; ++i) {
        printf("Object %d: ", i + 1);
        printf("Profit: ");
        scanf("%f", &objects[i].profit);
        printf("Weight: ");
        scanf("%f", &objects[i].weight);
        objects[i].ratio = objects[i].profit / objects[i].weight;
    }

    int W;
    printf("Enter the maximum weight capacity of the bag: ");
    scanf("%d", &W);

    float cur_w = W;
    float tot_v = 0.0;

    mergeSort(objects, 0, n - 1);

    for (int i = 0; i < n; ++i) {
        if (cur_w >= objects[i].weight) {
            cur_w -= objects[i].weight;
            tot_v += objects[i].profit;
            printf("Added object %d completely in the bag. Space left: %.2f.\n", i + 1, cur_w);
        } else {
            float fraction = cur_w / objects[i].weight;
            tot_v += objects[i].profit * fraction;
            printf("Added %.2f%% of object %d in the bag.\n", fraction * 100, i + 1);
            break;
        }
    }
    printf("Filled the bag with objects worth %.2f.\n", tot_v);
    return 0;
}