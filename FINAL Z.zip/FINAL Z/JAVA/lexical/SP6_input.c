void main(){
printf("hello");
}